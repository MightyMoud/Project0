$(document).ready(function() {
    $('.slider').slick({
        dots: true,
        sliderToShow: 2,
        adaptiveHeight: true
    });
});